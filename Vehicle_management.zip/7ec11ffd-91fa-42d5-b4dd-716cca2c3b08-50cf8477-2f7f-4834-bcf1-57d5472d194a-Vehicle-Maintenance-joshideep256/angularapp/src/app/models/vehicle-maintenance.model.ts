export interface VehicleMaintenance {
    serviceId?: number; 
    serviceName: string;
    servicePrice: number;
    typeOfVehicle: string;
    description?:string;
}