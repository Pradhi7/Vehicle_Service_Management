import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
 
@Injectable({
  providedIn: 'root',
})
export class AdminAuthGuard implements CanActivate {
  constructor(private router: Router) {}
 
  canActivate(): boolean {
    const role = localStorage.getItem('userRole'); // Get role from localStorage
    const isAuthenticated = !!localStorage.getItem('token') && role === 'Admin';
  
    console.log('Role:', role);
    console.log('Is Authenticated:', isAuthenticated);
  
    if (!isAuthenticated) {
      this.router.navigate(['/unauthorized']); // Redirect if not authenticated as admin
      return false;
    }
    return true;
  }
  
}
